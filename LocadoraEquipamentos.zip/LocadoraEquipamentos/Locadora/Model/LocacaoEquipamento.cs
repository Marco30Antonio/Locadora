﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Locadora.Model
{
  public  class LocacaoEquipamento
    {
        private int idEquipamento;
        private int idReserva;

        public int IdEquipamento { get => idEquipamento; set => idEquipamento = value; }
        public int IdReserva { get => idReserva; set => idReserva = value; }
    }
}
