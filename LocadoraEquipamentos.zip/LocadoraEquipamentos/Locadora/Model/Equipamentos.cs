﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Locadora.Model
{
    public class Equipamentos:Produto
    {
        private int idEquipamento;
        private decimal valorLocacao;

        public int IdEquipamento { get => idEquipamento; set => idEquipamento = value; }
        public decimal ValorLocacao { get => valorLocacao; set => valorLocacao = value; }
    }
}
