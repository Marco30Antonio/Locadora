﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Locadora.Model
{
   public class Estudios
    {
        private int idEstudios;
        private string descricaoServico;
        private string especificacaoServico;
        private string formato;
        private string midia;
       

        public string DescricaoServico { get => descricaoServico; set => descricaoServico = value; }
        public string EspecificacaoServico { get => especificacaoServico; set => especificacaoServico = value; }
        public string Formato { get => formato; set => formato = value; }
        public string Midia { get => midia; set => midia = value; }
        public int IdEstudios { get => idEstudios; set => idEstudios = value; }
    }
}
