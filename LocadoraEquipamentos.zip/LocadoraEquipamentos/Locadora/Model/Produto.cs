﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Locadora.Model
{
    public abstract class Produto
    {
        
        private string acessorios;
        private string descricao;
        private string modelo;
        private string marca;

        
        public string Acessorios { get => acessorios; set => acessorios = value; }
        public string Descricao { get => descricao; set => descricao = value; }
        public string Modelo { get => modelo; set => modelo = value; }
        public string Marca { get => marca; set => marca = value; }
    }
}
