﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Locadora.Model
{
  public  class Locacao
    {
        private int idLocacao;
        private int idCliente;
        private DateTime dataLocacao;
        private DateTime dataDevolucao;

        public int IdLocacao { get => idLocacao; set => idLocacao = value; }
        public int IdCliente { get => idCliente; set => idCliente = value; }            
        public DateTime DataLocacao { get => dataLocacao; set => dataLocacao = value; }
        public DateTime DataDevolucao { get => dataDevolucao; set => dataDevolucao = value; }
    }
}
