﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Locadora.Model;
using Locadora.DAO;
namespace Locadora.BO
{
    public class ClienteBo
    {
        public void Gravar(Cliente cliente)
        {
            ClienteDao clienteDao = new ClienteDao();
           if(cliente != null)
            {
                if (cliente.IdCliente != 0)
                {
                    clienteDao.Update(cliente);
                }
                else
                {
                    clienteDao.Insert(cliente);
                }
            }
        }

        public void ExcluirCliente(Cliente cliente)
        {
            ClienteDao clienteDao = new ClienteDao();
            ClienteBo clienteBo = new ClienteBo();
           
            if (clienteBo.ConferirExiteCliente(cliente) == null)            {

                clienteDao.Delete(cliente);
            }

        }

        public IList<Cliente> ConferirExiteCliente(Cliente cliente)
        {
            ClienteDao clienteDao = new ClienteDao();
           return clienteDao.Localizar(cliente);
            
        }
    }
}
