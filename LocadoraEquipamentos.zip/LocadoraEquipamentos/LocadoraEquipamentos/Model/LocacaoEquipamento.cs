﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocadoraEquipamentos.Model
{
   public class LocacaoEquipamento
    {
        private int idEquipamento;
        private int idReserva;

        public LocacaoEquipamento()
        {
        }

        public LocacaoEquipamento(int idEquipamento, int idReserva)
        {
            this.idEquipamento = idEquipamento;
            this.idReserva = idReserva;
        }

        public int IdEquipamento { get => idEquipamento; set => idEquipamento = value; }
        public int IdReserva { get => idReserva; set => idReserva = value; }
    }
}
