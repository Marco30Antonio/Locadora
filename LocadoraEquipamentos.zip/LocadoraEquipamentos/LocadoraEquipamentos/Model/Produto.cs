﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocadoraEquipamentos.Model
{
   public class Produto
    {
        private string acessorios;
        private string descricao;
        private string modelo;
        private string marca;

        public Produto()
        {
        }

        public Produto(string acessorios, string descricao, string modelo, string marca)
        {
            this.Acessorios = acessorios;
            this.Descricao = descricao;
            this.Modelo = modelo;
            this.Marca = marca;
            
        }

        public string Acessorios { get => acessorios; set => acessorios = value; }
        public string Descricao { get => descricao; set => descricao = value; }
        public string Modelo { get => modelo; set => modelo = value; }
        public string Marca { get => marca; set => marca = value; }
    }

}
