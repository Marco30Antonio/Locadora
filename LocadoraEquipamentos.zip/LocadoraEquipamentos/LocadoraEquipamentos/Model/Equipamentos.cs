﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocadoraEquipamentos.Model
{
   public class Equipamentos:Produto
    {
        private int idEquipamento;
        private decimal valorLocacao;

        public Equipamentos()
        {
        }

        public Equipamentos(int idEquipamento, decimal valorLocacao)
        {
            this.idEquipamento = idEquipamento;
            this.valorLocacao = valorLocacao;
        }

        public int IdEquipamento { get => idEquipamento; set => idEquipamento = value; }
        public decimal ValorLocacao { get => valorLocacao; set => valorLocacao = value; }
    }
}
