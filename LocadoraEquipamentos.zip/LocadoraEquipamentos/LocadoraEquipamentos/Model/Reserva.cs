﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocadoraEquipamentos.Model
{
   public class Reserva
    {
        private int idReserva;
        private int idCliente;
        private DateTime dataReserva;
        private DateTime dataValidade;

        public Reserva()
        {
        }

        public Reserva(int idReserva, int idCliente, DateTime dataReserva, DateTime dataValidade)
        {
            this.idReserva = idReserva;
            this.idCliente = idCliente;
            this.dataReserva = dataReserva;
            this.dataValidade = dataValidade;
        }

        public int IdReserva { get => idReserva; set => idReserva = value; }
        public int IdCliente { get => idCliente; set => idCliente = value; }
        public DateTime DataReserva { get => dataReserva; set => dataReserva = value; }
        public DateTime DataValidade { get => dataValidade; set => dataValidade = value; }
    }
}
