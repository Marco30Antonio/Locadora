﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace LocadoraEquipamentos.Conexao
{
  public  class FabricaConexao
    {
        private string stringconnection = "data source = MARCO-PC;" +
            " initial catalog = locadora_Equipamentos;" +
            " integrated security = True; " +
            "MultipleActiveResultSets=True;App=EntityFramework ";
        private static SqlConnection objConexao = null;

        public FabricaConexao()
        {
            objConexao = new SqlConnection();
            objConexao.ConnectionString = stringconnection;
            objConexao.Open();
        }

        public static SqlConnection getConexao()
        {

            if (objConexao == null) 
            {
                new FabricaConexao();
            }
            return objConexao;
        }

        public static void fecharConexao()
        {
            objConexao.Close();
        }

        public static void Crud(SqlCommand comando)
        {
            SqlConnection con = getConexao();
            comando.Connection = con;
            comando.ExecuteNonQuery();
            con.Close();
        }

        public static SqlDataReader Selecionar(SqlCommand comando)
        {
            SqlConnection con = getConexao();
            comando.Connection = con;
            SqlDataReader dr = comando.ExecuteReader(CommandBehavior.CloseConnection);
            return dr;
        }
    }
}
