﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LocadoraEquipamentos.DAO;
using LocadoraEquipamentos.Model;
using System.Windows.Forms;

namespace LocadoraEquipamentos.Controller
{
  public  class ClienteCtr
    {
        public void Gravar(Cliente cliente)
        {
            ClienteDao clienteDao = new ClienteDao();
            if (cliente != null)
            {
               if (cliente.IdCliente != 0)
                {
                    clienteDao.Update(cliente);
                   MessageBox.Show("Os dados do cliente foram atualizados");                   
                }
                else
                {
                    clienteDao.Insert(cliente);
                    MessageBox.Show("Os dados do cliente foram salvos");
                }
            }
        }

        public void Atualizar(Cliente cliente)
        {
            ClienteDao clienteDao = new ClienteDao();
            if (cliente != null)
            {
                if (cliente.IdCliente != 0)
                {
                    clienteDao.Update(cliente);
                    MessageBox.Show("Os dados do cliente foram atualizados");
                }
                else
                {
                    clienteDao.Insert(cliente);
                    MessageBox.Show("Os dados do cliente foram salvos");
                }
            }
        }

        public void ExcluirCliente(Cliente cliente)
        {
            ClienteDao clienteDao = new ClienteDao();
            ClienteCtr clienteBo = new ClienteCtr();

            if (clienteBo.ConferirExiteCliente(cliente) == null)
            {

                clienteDao.Delete(cliente);
            }

        }

        public IList<Cliente> ConferirExiteCliente(Cliente cliente)
        {
            ClienteDao clienteDao = new ClienteDao();
            return clienteDao.Localizar(cliente);
        }

        public Cliente ClienteSelecionado { get; set; }

        public Cliente  LocalizarCliente(int id)
        {
            ClienteDao clienteDao = new ClienteDao();
            return ClienteSelecionado = clienteDao.LocalizarCliente(id);
            
        }
    }
}
