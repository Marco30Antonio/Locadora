﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using LocadoraEquipamentos.Model;
using LocadoraEquipamentos.Conexao;
using LocadoraEquipamentos.DAO;

namespace LocadoraEquipamentos.DAO
{
  public  class ClienteDao
    {
        public void Insert(Cliente cliente)
        {
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.CommandText = "INSERT into dbo.Cliente(cpf,nome,contato,rua,numero,bairro,cidade,estado) VALUES (@cpf,@nome,@contato,@rua,@numero,@bairro,@cidade,@estado);";
            sqlCommand.Parameters.AddWithValue("@cpf", cliente.Cpf);
            sqlCommand.Parameters.AddWithValue("@nome", cliente.Nome);
            sqlCommand.Parameters.AddWithValue("@contato", cliente.Contato);
            sqlCommand.Parameters.AddWithValue("@rua", cliente.Rua);
            sqlCommand.Parameters.AddWithValue("@numero", cliente.Numero);
            sqlCommand.Parameters.AddWithValue("@bairro", cliente.Bairro);
            sqlCommand.Parameters.AddWithValue("@cidade", cliente.Cidade);
            sqlCommand.Parameters.AddWithValue("@estado", cliente.Estado);
            FabricaConexao.Crud(sqlCommand);
        }

        public void Update(Cliente cliente)
        {
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.CommandText = "UPDATE dbo.Cliente  SET cpf =@cpf,nome =@nome,contato =@contato,rua=@rua,numero=@numero,bairro=@bairro,cidade=@cidade,estado=@estado WHERE idCliente =@idCliente;";
            sqlCommand.Parameters.AddWithValue("@cpf", cliente.Cpf);
            sqlCommand.Parameters.AddWithValue("@nome", cliente.Nome);
            sqlCommand.Parameters.AddWithValue("@contato", cliente.Contato);
            sqlCommand.Parameters.AddWithValue("@rua", cliente.Rua);
            sqlCommand.Parameters.AddWithValue("@numero", cliente.Numero);
            sqlCommand.Parameters.AddWithValue("@bairro", cliente.Bairro);
            sqlCommand.Parameters.AddWithValue("@cidade", cliente.Cidade);
            sqlCommand.Parameters.AddWithValue("@estado", cliente.Estado);
            sqlCommand.Parameters.AddWithValue("@idCliente", cliente.IdCliente);
            FabricaConexao.Crud(sqlCommand);
        }
        public void Delete(Cliente cliente)
        {
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.CommandText = "DELETE FROM dbo.Cliente WHERE idCliente =@idCliente;";
            sqlCommand.Parameters.AddWithValue("@idCliente", cliente.IdCliente);
            FabricaConexao.Crud(sqlCommand);
        }
        public Cliente LocalizarCliente(int id)
        {

            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.CommandText = "SELECT * FROM dbo.Cliente WHERE idCliente = @idCliente;";
            sqlCommand.Parameters.AddWithValue("@idCliente", id);
            SqlDataReader dr = FabricaConexao.Selecionar(sqlCommand);
            Cliente cliente = new Cliente();
            if (dr.HasRows)
            {
                dr.Read();
                cliente.IdCliente = (int)dr["idCliente"];
                cliente.Cpf = (int)dr["cpf"];
                cliente.Nome = (string)dr["nome"];
                cliente.Contato = (string)dr["contato"];
                cliente.Rua = (string)dr["rua"];
                cliente.Numero = (int)dr["numero"];
                cliente.Bairro = (string)dr["bairro"];
                cliente.Cidade = (string)dr["cidade"];
                cliente.Estado = (string)dr["estado"];

            }
            else
            {
                cliente = null;
            }
            return cliente;

        }

        public IList<Cliente> Localizar(Cliente cliente)
        {

            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.CommandText = "SELECT * FROM dbo.Cliente WHERE nome like @idCliente;";
            sqlCommand.Parameters.AddWithValue("@idCliente", cliente.IdCliente);
            SqlDataReader dr = FabricaConexao.Selecionar(sqlCommand);
            IList<Cliente> clientes = new List<Cliente>();
            if (dr.HasRows)
            {
                while (dr.Read())
                {

                    new Cliente().IdCliente = (int)dr["idCliente"];
                    new Cliente().Cpf = (int)dr["cpf"];
                    new Cliente().Nome = (string)dr["nome"];
                    new Cliente().Contato = (string)dr["contato"];
                    new Cliente().Rua = (string)dr["rua"];
                    new Cliente().Numero = (int)dr["numero"];
                    new Cliente().Bairro = (string)dr["bairro"];
                    new Cliente().Cidade = (string)dr["cidade"];
                    new Cliente().Estado = (string)dr["estado"];
                    clientes.Add(cliente);

                }
            }
            else
            {
                clientes = null;
            }
            return clientes;
        }
    }
}
