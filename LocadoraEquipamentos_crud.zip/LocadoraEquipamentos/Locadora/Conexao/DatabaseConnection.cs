using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Locadora.Conexao
{
   
    class DatabaseConnection
    {
       
        public static SqlConnection Conexao()
        {

            string conexaoString = GetString();
            using (SqlConnection conexao = new SqlConnection(conexaoString))
            {
                try {
                    conexao.Open();
                    return conexao;
                    Console.WriteLine("State: {0}", conexao.State);
                    Console.WriteLine("ConnectionString: {0}",
                    conexao.ConnectionString);
                   

                } catch
                {
                    conexao.Dispose();

                }
              

            }
            return Conexao();
        }

        public static SqlConnection GetConexao()
        {
            return Conexao();
        }


         static private string GetString()
        {

            return "Data Source=MARCO-PC;Initial Catalog=locadora_Equipamentos;"
              + "User id=MARCO-PC/lucas;" +
              "Password=Admim@Admim;"; ;
        }

        public static void CRUD(SqlCommand comando)
        {
            SqlConnection con = GetConexao();
            comando.Connection = con;
            comando.ExecuteNonQuery();
            con.Close();
        }
        
        public static SqlDataReader Selecionar(SqlCommand comando)
        {
            SqlConnection con = GetConexao();
            comando.Connection = con;
            SqlDataReader dr = comando.ExecuteReader(CommandBehavior.CloseConnection);
            return dr;
        }

    }

}

