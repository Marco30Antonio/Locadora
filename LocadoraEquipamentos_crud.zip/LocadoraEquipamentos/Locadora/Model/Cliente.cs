﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Locadora.Model
{
  public  class Cliente
    {
        private int idCliente;
        private int cpf;
        private string nome;
        private string contato;
        private string rua;
        private int numero;
        private string bairro;
        private string cidade;
        private string estado;

        public string Estado { get => estado; set => estado = value; }
        public string Cidade { get => cidade; set => cidade = value; }
        public string Bairro { get => bairro; set => bairro = value; }
        public int Numero { get => numero; set => numero = value; }
        public string Rua { get => rua; set => rua = value; }
        public string Contato { get => contato; set => contato = value; }        
        public int Cpf { get => cpf; set => cpf = value; }
        public int IdCliente { get => idCliente; set => idCliente = value; }
        public string Nome { get => nome; set => nome = value; }
    }
}
