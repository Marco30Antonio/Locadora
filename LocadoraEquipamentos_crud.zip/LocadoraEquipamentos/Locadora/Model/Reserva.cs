﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Locadora.Model
{
   public class Reserva
    {
        private int idReserva;
        private int idCliente;
        private DateTime dataReserva;
        private DateTime dataValidade;

        public DateTime DataValidade { get => dataValidade; set => dataValidade = value; }
        public DateTime DataReserva { get => dataReserva; set => dataReserva = value; }
        public int IdCliente { get => idCliente; set => idCliente = value; }
        public int IdReserva { get => idReserva; set => idReserva = value; }
    }
}
