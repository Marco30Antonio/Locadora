﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LocadoraEquipamentos.Controller;
using LocadoraEquipamentos.Model;

namespace LocadoraEquipamentos
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)

        {

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
              if(txtId.Text=="") {

                    MessageBox.Show("Digite: 0 no campo ID para salvar ou digite o código do cliente para atualizar");

                } else if(txtNome.Text == "")

                {
                    MessageBox.Show("Informe o nome do cliente.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if( txtCpf.Text =="")
                {
                    MessageBox.Show("Informe o cpf do cliente.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }else if(txtContato.Text == "")
                {
                    MessageBox.Show("Informe o nome do cliente.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }else if(txtEndereco.Text == "")
                {
                    MessageBox.Show("Informe o endereço do  cliente.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }else if(txtNumero.Text == "")
                {
                    MessageBox.Show("Informe o número da casa do  cliente.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }else if(txtBairro.Text == "")
                {
                    MessageBox.Show("Informe o Bairro do  cliente.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }else if ( txtCidade.Text == "") {

                    MessageBox.Show("Informe a cidade do  cliente.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }else if(txtEstado.Text == "")
                {
                    MessageBox.Show("Informe o Esatdo do  cliente.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {   
                    int idCliente = Convert.ToInt32(txtId.Text);
                    int cpf = Convert.ToInt32(txtCpf.Text);
                    string nome = txtNome.Text;
                    string contato = txtContato.Text;
                    string rua = txtEndereco.Text;
                    int numero = Convert.ToInt32(txtNumero.Text); ;
                    string bairro = txtBairro.Text;
                    string cidade = txtCidade.Text;
                    string estado = txtEstado.Text;
                    ClienteCtr clienteCtr = new ClienteCtr();
                    Cliente cliente = new Cliente();

                    cliente.IdCliente = idCliente;
                    cliente.Cpf = cpf;
                    cliente.Nome = nome;                 
                    cliente.Contato = contato;
                    cliente.Rua = rua;
                    cliente.Numero = numero;
                    cliente.Bairro = bairro;
                    cliente.Cidade = cidade;
                    cliente.Estado = estado;

                    clienteCtr.Gravar(cliente);

                   }
             }
            catch
            {
                
            }

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtEstado_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (txtId.Text == "")
            {

                MessageBox.Show("Digite: 0 no campo ID para salvar ou digite o código do cliente para atualizar");

            }
            else
            {
                int idCliente = Convert.ToInt32(txtId.Text);
                int cpf = Convert.ToInt32(txtCpf.Text);
                string nome = txtNome.Text;
                string contato = txtContato.Text;
                string rua = txtEndereco.Text;
                int numero = Convert.ToInt32(txtNumero.Text); ;
                string bairro = txtBairro.Text;
                string cidade = txtCidade.Text;
                string estado = txtEstado.Text;
                ClienteCtr clienteCtr = new ClienteCtr();
                Cliente cliente = new Cliente();

                cliente.IdCliente = idCliente;
                cliente.Cpf = cpf;
                cliente.Nome = nome;
                cliente.Contato = contato;
                cliente.Rua = rua;
                cliente.Numero = numero;
                cliente.Bairro = bairro;
                cliente.Cidade = cidade;
                cliente.Estado = estado;
                clienteCtr.Gravar(cliente);
                


            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            int idCliente = Convert.ToInt32(txtId.Text);
            ClienteCtr clienteCtr = new ClienteCtr();
            clienteCtr.LocalizarCliente(idCliente);
            if (clienteCtr.ClienteSelecionado != null)
            {
                txtId.Text = Convert.ToString(clienteCtr.ClienteSelecionado.IdCliente);
                txtCpf.Text = Convert.ToString(clienteCtr.ClienteSelecionado.Cpf);
                txtNome.Text = clienteCtr.ClienteSelecionado.Nome;
                txtContato.Text = clienteCtr.ClienteSelecionado.Contato;
                txtEndereco.Text = clienteCtr.ClienteSelecionado.Rua;
                txtNumero.Text = Convert.ToString(clienteCtr.ClienteSelecionado.Numero);
                txtBairro.Text = clienteCtr.ClienteSelecionado.Bairro;
                txtCidade.Text = clienteCtr.ClienteSelecionado.Cidade;
                txtEstado.Text = clienteCtr.ClienteSelecionado.Estado;
            }
            else
            {
                MessageBox.Show("Não foi encontrado um cliente para esse id ");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int idCliente = Convert.ToInt32(txtId.Text);
            if (idCliente != 0)
            {
                ClienteCtr clienteCtr = new ClienteCtr();
                Cliente cliente = new Cliente();
                cliente.IdCliente = idCliente;
                clienteCtr.ExcluirCliente(cliente);
            }
        }
    }
}
