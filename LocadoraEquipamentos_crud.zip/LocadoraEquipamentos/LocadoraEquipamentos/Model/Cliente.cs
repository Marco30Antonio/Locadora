﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocadoraEquipamentos.Model
{
   public class Cliente
    {
        private int idCliente;
        private int cpf;
        private string nome;
        private string contato;
        private string rua;
        private int numero;
        private string bairro;
        private string cidade;
        private string estado;

        public Cliente()
        {
        }

        public Cliente(int idCliente, int cpf, string nome, string contato, string rua, int numero, string bairro, string cidade, string estado)
        {
            this.IdCliente = idCliente;
            this.Cpf = cpf;
            this.Nome = nome;
            this.Contato = contato;
            this.Rua = rua;
            this.Numero = numero;
            this.Bairro = bairro;
            this.Cidade = cidade;
            this.Estado = estado;
          
        }

        public int IdCliente { get => idCliente; set => idCliente = value; }
        public int Cpf { get => cpf; set => cpf = value; }
        public string Nome { get => nome; set => nome = value; }
        public string Contato { get => contato; set => contato = value; }
        public string Rua { get => rua; set => rua = value; }
        public int Numero { get => numero; set => numero = value; }
        public string Bairro { get => bairro; set => bairro = value; }
        public string Cidade { get => cidade; set => cidade = value; }
        public string Estado { get => estado; set => estado = value; }
    }
}
